﻿namespace ChatCore
{
  public class CMessage
  {
  }
}
